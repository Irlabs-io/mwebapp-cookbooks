## 0.2.1
* Allow discovery port to be specified via attribute

## 0.2.0
* Refactor image pull into it's own recipe 

## 0.1.2
* Add attribute for worker advertise address
* Bind service to 0.0.0.0:2376
* Additional testing and documentation

## 0.1.0
Inital release
