Changelog
=========

1.0.0
-----

- Initial version working with consul 0.7.2.
